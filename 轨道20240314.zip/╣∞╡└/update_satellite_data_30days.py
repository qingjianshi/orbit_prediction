# -*- coding: utf-8 -*-
import warnings

# 例如，忽略所有的运行时警告
warnings.filterwarnings("ignore")
from sgp4.api import Satrec
from astropy.time import Time
from astropy.coordinates import CartesianDifferential, CartesianRepresentation
from astropy.coordinates import TEME, ITRS
from astropy import units as u
from datetime import datetime, timedelta
from pytz import timezone
import pandas as pd
from timezonefinder import TimezoneFinder
from sqlalchemy.orm import declarative_base
import pytz
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, Text, TIMESTAMP, Float
import geopandas as gpd
from shapely.geometry import Point, LineString
from geoalchemy2 import Geometry
from pyproj import Geod
pd.set_option('display.encoding', 'utf-8')
#创建时区转换
timezone_finder = TimezoneFinder()
Local_time=[]
satellite_width = {'ZIYUAN1-02C(ZY1-02C)': 60000, 'ZIYUAN3-1(ZY3-1)': 50000, 'ZIYUAN3-2(ZY3-2)': 50000,
                       'ZY-102D': 115000, 'ZY-102E': 115000, 'GAOFEN1': 60000, 'GAOFEN1-02': 60000, 'GAOFEN1-03': 60000,
                       'GAOFEN1-04': 60000, 'GAOFEN2': 45000, 'GAOFEN3': 130000, 'GAOFEN3-02': 130000,
                       'GAOFEN3-03': 650000, 'GAOFEN6': 90000, 'GAOFEN7': 20000,
                       'HAIYANG-1B': 512000,
                       'HAIYANG-1C': 2900000, 'HAIYANG-1D': 2900000, 'GAOFEN5': 60000, 'GAOFEN5-01': 60000,
                       'GAOFEN5-01A': 60000, 'GAOFEN5-02': 60000}
def CreateConnection(database_name,database_username,database_password,database_host,database_post):
    url = 'postgresql://{}:{}@{}:{}/{}'
    url=url.format(database_username,database_password,database_host,database_post,database_name)
    engine = create_engine(url)
    conn=engine.connect()
    return engine
engine= CreateConnection(database_name='postgres', database_username='postgres', database_password='ecnu2024',database_host='49.52.31.105',database_post='5434')

def crawl_satellite_data():
    #计算当前utc时间，设置时间段和间隔
    now = datetime.now()
    utc_now = now.astimezone(timezone('UTC'))
    tstart=utc_now-timedelta(days=1)
    stop_offset = '86400s'
    freq = '5min'
    end_date = tstart + timedelta(days=30)
    day=0
    while tstart < end_date:
        day = day + 1
        # tstart = tstart.replace(hour=0, minute=0, second=0, microsecond=0)+pd.to_timedelta('86400s')
        tstart = tstart+pd.to_timedelta('86400s')
        tstop = tstart + pd.to_timedelta(stop_offset)
        times = pd.date_range(tstart, tstop, freq=freq)
        Name = []
        Line1 = []
        Line2 = []

        with open("tle_para_res.txt", "r", encoding='utf-8') as file:
            lines = file.readlines()

        # 处理每三行的数据，并添加到相应的列表中
        for i in range(0, len(lines), 3):
            dfs = []
            name = lines[i].strip().replace(" ", "")  # 处理第一行，并移除换行符和空格
            line1 = lines[i + 1].strip()  # 处理第二行，并移除换行符
            line2 = lines[i + 2].strip()  # 处理第三行，并移除换行符

            Name.append(name)
            Line1.append(line1)
            Line2.append(line2)
            satellite = Satrec.twoline2rv(line1, line2)
            geodetic_orbit = []
            for time in times:
                t = Time(time)
        #设定速度
                error_code, teme_p, teme_v = satellite.sgp4(t.jd1, t.jd2)
                teme_p = CartesianRepresentation(teme_p * u.km)#将位置表示为千米单位的卫星TEME坐标。
                teme_v = CartesianDifferential(teme_v * u.km / u.s)#速度表示为千米/秒单位的卫星TEME坐标。
                teme = TEME(teme_p.with_differentials(teme_v), obstime=t)#TEME坐标系对象，该对象包含卫星的位置和速度信息，并且与给定的时间相关联。

            # Convert to ITRS and geodetic coordinates
                itrs = teme.transform_to(ITRS(obstime=t))
                geodetic = itrs.earth_location.to_geodetic()
                target_timezone_str = timezone_finder.timezone_at(lng=geodetic.lon.value,
                                                                  lat=geodetic.lat.value)

                parsed_time =time
                target_timezone = pytz.timezone(target_timezone_str)
                local_time = parsed_time.astimezone(target_timezone)
                local_time=datetime.strptime(str(local_time), "%Y-%m-%d %H:%M:%S.%f%z").strftime("%Y-%m-%dT%H:%M:%SZ")
                geodetic_orbit.append({'time_utc': time,
                                               'height': geodetic.height.value*1000,
                                               'lat': geodetic.lat.value,
                                               'lon': geodetic.lon.value,
                                        'time_local':local_time,
                                       'time_zone':target_timezone_str,
                                               })
        # 数据存为dataframe，csv
                df = pd.DataFrame(geodetic_orbit)
                df.index = df['time_utc']
                df['name']=name.strip().replace(" ","")
                df['time_utc']=pd.to_datetime(df['time_utc'])
                df['time_iso'] = df['time_utc'].dt.strftime('%Y-%m-%dT%H:%M:%SZ')
                df.drop_duplicates(inplace=True)
                dfs.append(df)
            all_data = pd.concat(dfs, ignore_index=True)
            all_data.drop_duplicates(inplace=True)
            all_data.reset_index(drop=True, inplace=True)
            # 为了创建线段，我们首先需要将经纬度转换为点
            all_data['point'] = [Point(xy) for xy in zip(all_data['lon'], all_data['lat'])]
            # 创建Geod对象，用WGS84椭球体参数
            geod = Geod(ellps='WGS84')
            # 接着，创建线段。首行和尾行只有一条连接线，中间行有两条连接线
            Lines = []
            for j in range(len(all_data)):
                if j == 0:  # 第一行
                    lonlats = geod.npts(all_data['lon'].iloc[j], all_data['lat'].iloc[j], all_data['lon'].iloc[j + 1],
                                        all_data['lat'].iloc[j + 1], 10)
                    lonlats.insert(0, (all_data['lon'].iloc[j], all_data['lat'].iloc[j]))
                    lonlats.append((all_data['lon'].iloc[j + 1], all_data['lat'].iloc[j + 1]))
                    line = LineString(lonlats)
                elif j == len(all_data) - 1:  # 最后一行
                    lonlats = geod.npts(all_data['lon'].iloc[j - 1], all_data['lat'].iloc[j - 1],
                                        all_data['lon'].iloc[j], all_data['lat'].iloc[j], 10)
                    lonlats.insert(0, (all_data['lon'].iloc[j - 1], all_data['lat'].iloc[j - 1]))
                    lonlats.append((all_data['lon'].iloc[j], all_data['lat'].iloc[j]))
                    line = LineString(lonlats)
                else:  # 中间行
                    line = LineString([all_data['point'].iloc[j - 1], all_data['point'].iloc[j], all_data['point'].iloc[j + 1]])
                Lines.append(line)
            # 将线段列表转换为GeoSeries
            geo_series = gpd.GeoSeries(Lines)
            # 将GeoSeries作为新列添加到DataFrame中
            all_data['geometry'] = geo_series
            all_data.drop('point',axis=1)
            # 将DataFrame转换为GeoDataFrame
            all_data = all_data[['name', 'time_utc', 'time_iso', 'time_local','time_zone','lat', 'lon', 'height','geometry']]
            all_data['time_utc'] = all_data['time_utc'].dt.tz_localize(None)
            # 使用PyProj的CRS格式
            gdf = gpd.GeoDataFrame(all_data, crs='EPSG:4326', geometry='geometry')
            # 创建一个元数据对象
            metadata = MetaData()
            Base = declarative_base()

            class OrbitPrediction(Base):
                __tablename__ = 'orbit_prediction_30days'

                id = Column(Integer, primary_key=True, autoincrement=True)
                name = Column(Text)
                time_utc = Column(TIMESTAMP(timezone=False))
                time_iso = Column(Text)
                time_local = Column(Text)
                time_zone = Column(Text)
                lat = Column(Float)
                lon = Column(Float)
                height = Column(Float)
                geometry=Column(Geometry(srid=4326))

            # Create the table if it doesn't exist
            Base.metadata.create_all(engine, checkfirst=True)
            with engine.connect() as connection:
                gdf.to_postgis('orbit_prediction_30days', con=connection, schema='postgres', if_exists='append', index=False)
                print(f"第{day}天,{name}文件数据已成功添加到数据库表中")
def main():
    crawl_satellite_data()
if __name__ == "__main__":
    main()
